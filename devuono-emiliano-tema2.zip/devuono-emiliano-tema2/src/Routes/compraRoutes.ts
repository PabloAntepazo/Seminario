import compraController from '../controller/compraControllers';
import { Router, Request, Response } from 'express';


class CompraRoutes{
	public router: Router = Router();
	constructor(){
		this.config();
	}
	config():void{
		this.router.get('/',(req:Request,res:Response)=> 
        res.send("Main!!!!!!!!!!!"));


		this.router.get("/listar", compraController.verCarrito );
		this.router.post("/confirmar", compraController.comprar );
    }
}

const compraRoutes = new CompraRoutes();
export default compraRoutes.router;