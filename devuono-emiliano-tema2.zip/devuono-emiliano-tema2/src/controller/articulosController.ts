import { Request, Response } from "express";
import articulosModel from "../models/articulosModels";
import flash from "connect-flash";

class ArticulosController {

  public async listar(req: Request, res: Response) {
    if (!req.session.auth) {
      req.flash("error_session", "Debes iniciar sesion para ver esta seccion");
      res.redirect("./error");
      //res.redirect("/");
    }
    console.log(req.body);
    const articulos = await articulosModel.listar();
    res.render("partials/listar", {
      variedades: articulos,
      carrito: 0,
    })
  }

  public agregar (req: Request, res: Response){
    if (!req.session.auth) {
      req.flash("error_session", "Debes iniciar sesion para ver esta seccion");
      res.redirect("./error");
      //res.redirect("/");
    }

    const{id, nombre, cantidad, precio} = req.body;

    let SessionCarrito = req.session.carrito;

    if(!SessionCarrito)
    {
      SessionCarrito = []; //se transfomra en un arrays
    }
    const subtotal = precio*cantidad;

    SessionCarrito.push({id, nombre, cantidad ,precio, subtotal });
    req.session.carrito = SessionCarrito;
    console.log(SessionCarrito);
    req.flash("mensajearticulo", "Articulos Agregados al Carrito");
    res.redirect("../listar");


  }



}



const articulosController = new ArticulosController();
export default articulosController;
