import { Request, Response } from "express";
import compraModel from "../models/compraModels";
import flash from "connect-flash";

class CompraController {

    public verCarrito(req: Request, res: Response) {
        if (!req.session.auth) {
            req.flash("error_session", "Debes iniciar sesion para ver esta seccion");
            res.redirect("./error");
            //res.redirect("/");
          }
        const carrito = req.session.carrito;
        res.render("partials/carrito", { carrito: carrito  });
    }


    public async comprar(req: Request, res: Response) {
        if (!req.session.auth) {
            req.flash("error_session", "Debes iniciar sesion para ver esta seccion");
            res.redirect("./error");
            //res.redirect("/");
          }
        var tot: number = 0;
        const { calle, altura } = req.body;
        const carrito = req.session.carrito;
        for (let value of carrito) {
			const { subtotal } = value;
            console.log(subtotal);
            tot = tot + parseFloat(subtotal);
            console.log(tot);
        }
        const ok = await compraModel.comprar(carrito, calle, altura, tot);
        const idPedido = await compraModel.buscarIdPedido();
        const {id} = idPedido;
        console.log(calle, altura, tot, idPedido);
        //res.render("partials/factura", {calle, altura, total, idPedido});
        res.render("partials/confirmacion", { calle, altura, tot, id});
        tot=0;
        req.session.carrito= [];


    }

}



const compraController = new CompraController();
export default compraController;
