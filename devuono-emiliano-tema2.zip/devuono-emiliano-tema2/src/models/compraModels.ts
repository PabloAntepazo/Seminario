import { createPool } from 'mysql2/promise';

class CompraModel {
	private db: any;
	constructor() {
		this.config(); //aplicamos la conexion con la BD.
	}



	async config() {//Parametro de conexion con la BD.
		this.db = await createPool({
			host: '127.0.0.1',
			user: 'root',
			password: '',
			database: 'pedidost2',
			connectionLimit: 10
		});
	}


	async comprar(carrito: any[], calle: string, altura: number, total: number) {

		const pedidoId = (
			await this.db.query("INSERT INTO pedidos (calle, altura, total) values(?,?,?)", [calle, altura, total])
		)[0].insertId;

		for (let value of carrito) {
			const { id, cantidad, precio } = value;

			const result = (
				await this.db.query("INSERT INTO pedidos_articulos (id_pedido ,id_articulo, precio, cantidad) values(? ,?, ?, ?)",
					[pedidoId, id, precio, cantidad])
			)[0].affectedRows;
		}
	}

	async buscarIdPedido() {
		const id: any = await this.db.query('SELECT max(id) as id FROM pedidos');
		//Ojo la consulta devuelve una tabla de una fila. (Array de array) Hay que desempaquetar y obtener la unica fila al enviar
		if (id.length > 1)
			return id[0][0];
		return null; 
	}
}

const compraModel: CompraModel = new CompraModel();
export default compraModel;