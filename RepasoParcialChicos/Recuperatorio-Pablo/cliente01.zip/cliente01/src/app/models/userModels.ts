export interface Articulo {
  id?: string;
  descripcion?: string;
  precio?: string;
}
