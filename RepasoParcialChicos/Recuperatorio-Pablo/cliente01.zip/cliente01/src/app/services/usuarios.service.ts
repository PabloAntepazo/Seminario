import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { Articulo } from '../models/userModels';

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {

  API_URI = "http://localhost:3000/user";
  API_URI2 = "http://localhost:3000/admin";

  constructor(private http: HttpClient, private router: Router) { }


  ingresar(usuario: any) {
    return this.http.post(`${this.API_URI}/signin`, usuario);
  }

  listarProductos() {
    return this.http.get(`${this.API_URI2}/listarpedidos`);
  }

  abmproductos() {
    return this.http.get(`${this.API_URI2}/abmproductos`);
  }

  guardarProducto(articulo: Articulo) {
    return this.http.post(`${this.API_URI2}/agregar`, articulo);
  }

  eliminarProducto(id: string) {
    return this.http.delete(`${this.API_URI2}/delete/${id}`);
  }

  actualizarProducto(id: string, actualizarArt: Articulo): Observable<Articulo> {
    return this.http.put(`${this.API_URI2}/modificar/${id}`, actualizarArt);
  }
}
