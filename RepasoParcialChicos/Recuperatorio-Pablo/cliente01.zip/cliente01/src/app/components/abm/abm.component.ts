import { Component, OnInit } from '@angular/core';
import { UsuariosService } from '../../services/usuarios.service';


@Component({
  selector: 'app-abm',
  templateUrl: './abm.component.html',
  styleUrls: ['./abm.component.css']
})
export class AbmComponent implements OnInit {
  articulos: any = [];
  constructor(private usuariosService: UsuariosService) { }

  ngOnInit(): void {
    this.usuariosService.abmproductos().subscribe(
      res => {
        this.articulos = res;
        console.log(res)
      },
      err => console.log(err)
    )
  }
}
