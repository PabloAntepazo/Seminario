import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsuariosIngresarComponent } from "./components/usuarios-ingresar/usuarios-ingresar.component"
import { AbmComponent } from "./components/abm/abm.component"
import { InicioComponent } from './components/inicio/inicio.component';

const routes: Routes = [

  {
    path: '',
    redirectTo: 'usuarios/inicio',
    pathMatch: 'full'
  },
  {
    path: 'usuarios/ingresar',
    component: UsuariosIngresarComponent
  },
  {
    path: 'usuarios/inicio',
    component: InicioComponent
  },
  {
    path: 'admin/abm',
    component: AbmComponent,
    //canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
