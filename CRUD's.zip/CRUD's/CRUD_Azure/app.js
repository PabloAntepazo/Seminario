const CosmosClient = require("@azure/cosmos").CosmosClient;
const config = require("./config");
const dbContext = require("./data/databaseContext");
const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const { endpoint, key, databaseId, containerId } = config;
const client = new CosmosClient({ endpoint, key });
const database = client.database(databaseId);
const container = database.container(containerId);
//await dbContext.create(client, databaseId, containerId);


// READ todos los items del conteiner
app.get('/listar', async function (req, res) {
    const querySpec = {
        query: "SELECT * from c"
    };

    const { resources: items } = await container.items
        .query(querySpec)
        .fetchAll();

    res.json({
        items
    })

    items.forEach(item => {

        console.log(`${item.id} - ${item.category}`);
    });

})

// CREATE un item
app.post('/grabar', async function (req, res) {
    const newItem = {
        id: req.body.id,
        category: req.body.category,
        name: req.body.name,
        description: req.body.description,
        isComplete: req.body.isComplete
    };

    const { resource: createdItem } = await container.items.create(newItem);
    console.log(`\r\nItem Creado: ${createdItem.id} - ${createdItem.description}\r\n`);

    res.json({
        newItem
    });
});


// UPDATE un item
app.put('/actualizar/:id', async function (req, res) {
    const uptdItem = {
        id: req.body.id,
        category: req.body.category,
        name: req.body.name,
        description: req.body.description
    };

    uptdItem.isComplete = true;

    const { resource: updatedItem } =
        await container.item(uptdItem.id, uptdItem.category, uptdItem.name, uptdItem.description).replace(uptdItem);
    console.log(`Updated item: ${updatedItem.id} - ${updatedItem.description}\r\n`);
    console.log(`Updated name to ${updatedItem.name}\r\n`);
    console.log(`Updated Category to ${updatedItem.category}\r\n`);
    console.log(`Updated Description to ${updatedItem.description}\r\n`);
    console.log(`Updated isComplete to ${updatedItem.isComplete}\r\n`);
    res.send("Updated: " + req.body.id);

})


// DELETE un item
app.delete('/delete', async function (req, res) {

    var id = req.body.id;
    var category = req.body.category;

    console.log(id);

    const { resource: result } = await container.item(id, category).delete();
    console.log(`Deleted: ${id}`);

    res.send("Deleted: " + req.body.id)

})


app.listen(3000, () => {
    console.log("El servidor esta inicializado en el puerto 3000");
});
