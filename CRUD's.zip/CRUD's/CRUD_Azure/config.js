const config = {
    endpoint: "https://pabloantepazo.documents.azure.com:443/",
    key: "0hjkIAn8JktGEyvUS6fkq2l7bSIJqQpmo3pHznrERO1vysfNjX1LRTN67LVUu2bf9fSgO17jD7dYggeceIZ3lA==",
    databaseId: "Tasks",
    containerId: "Items",
    partitionKey: { kind: "Hash", paths: ["/category"] }
};

module.exports = config;