const express = require('express');
const bodyParser = require('body-parser');
var MongoClient = require('mongodb').MongoClient

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const url = "mongodb://127.0.0.1:8080";
const client = new MongoClient(url, { useUnifiedTopology: true });
client.connect();

app.get('/listar', async function (req, res) {
	var collection = await client.db().collection("test");
	const items = await collection.find().toArray();

	res.json({
		codigo: 200,
		descripcion: items
	});
});

app.post('/grabar', async function (req, res) {
	var id = req.body.id;
	var monto = req.body.monto;
	var codigoRetiro = req.body.codigoRetiro;

	console.log('id ' + id);
	console.log('Monto ' + monto);
	console.log('codigo retiro ' + codigoRetiro);

	var collection = await client.db().collection("test");
	await collection.insertOne({ id: id, monto: monto, codigo: codigoRetiro });

	res.json({
		codigo: req.body.codigoRetiro,
		descripcion: req.body.id
	});
});

app.put('/actualizar', async function (req, res) {
	var id = req.body.id;
	var monto = req.body.monto;
	var codigoRetiro = req.body.codigoRetiro;

	console.log("ACTUALIZACION");
	console.log('id ' + id);
	console.log('Monto ' + monto);
	console.log('codigo retiro ' + codigoRetiro);

	var collection = await client.db().collection("test");
	await collection.findOneAndUpdate({ id: id }, { $set: { monto: monto, codigo: codigoRetiro } });

	res.send("Updated: " + req.body.id);


})


app.delete('/delete/:id', async function (req, res) {
	var id = req.body.id;
	var collection = await client.db().collection("test");

	await collection.findOneAndDelete({ id });


	res.send("Deleted: " + req.body.id)


})

app.listen(5001, () => {
	console.log("El servidor esta inicializado en el puerto 5001");
});
